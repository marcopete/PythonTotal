import math

resultado = math.floor(89.665)
print(resultado)
resultado = math.ceil(89.665)
print(resultado)
resultado = math.pi
print(resultado)

resultado = math.log(100, 5)
print(resultado)
resultado = math.tan(45)
print(f'Gamulan que se duerme Tangente de 45: {resultado}')

# Obtener el logaritmo base 10 de 25
numero = 25
resultado = math.log10(numero)

# Imprimir el resultado
print("Logaritmo base 10 de", numero, "es:", resultado)

# Obtener la raíz cuadrada de pi
resultado = math.sqrt(math.pi)

# Imprimir el resultado
print("Raíz cuadrada de pi:", resultado)

# Calcular el factorial de 7
resultado = math.factorial(7)

# Imprimir el resultado
print("Factorial de 7:", resultado)


